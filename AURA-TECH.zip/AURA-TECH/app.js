const express = require('express');
const path = require('path');

const app = express();

const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Home route
app.get('/', (req, res) => {
    res.send('AURA TECH is running successfully.');
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log('================================');
    console.log('       AURA TECH SERVER');
    console.log('================================');
    console.log(`Server running on port ${PORT}`);
});